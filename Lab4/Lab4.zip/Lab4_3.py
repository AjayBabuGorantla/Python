def third():
    input1 = eval(input("Enter a number:"))
    while (input1<0) or (type(input1)!=int):
        input1 = eval(input("Enter a valid number:"))
    return sum_to(input1,0)
def sum_to(n,sum1):
    if(n==0):
        return sum1
    else:
        sum1+=n
        n-=1
        return sum_to(n,sum1)
print(third())