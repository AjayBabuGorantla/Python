s=(input("Enter number"))
print(s[s.__len__():0])