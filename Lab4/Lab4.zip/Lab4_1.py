def first():
    n = int(input("Enter the number:"))
    m = int(input("Enter another number:"))
    if(n%m==0 or m%n==0):
        return True
    else:
        return False
print(first())
