def is_even(n):
    return (n&1)
def second():
    input1 = int(input("Enter a number"))
    if(is_even(input1)):
        return False
    else:
        return True
print(second())
